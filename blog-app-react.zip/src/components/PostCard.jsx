import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function PostCard({ post, onDelete, onLike }) {
  const { user } = useAuth();
  const isAuthor = user && post.author._id === user.id;

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {post.image && (
        <img src={`http://localhost:5000${post.image}`} alt={post.title} className="w-full h-64 object-cover" />
      )}
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-2">{post.title}</h2>
        <p className="text-gray-600 mb-4 line-clamp-3">{post.content}</p>
        <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
          <span>By {post.author.username}</span>
          <span>{new Date(post.createdAt).toLocaleDateString()}</span>
        </div>
        <div className="flex justify-between items-center">
          <div className="flex gap-4">
            <button onClick={() => onLike(post._id)} className="text-red-500 hover:text-red-700">
              ❤️ {post.likes.length} Likes
            </button>
            <span>{post.comments.length} Comments</span>
          </div>
          <Link to={`/post/${post._id}`} className="text-blue-600 hover:underline">Read More →</Link>
        </div>
        {isAuthor && (
          <div className="mt-4 flex gap-2">
            <Link to={`/edit/${post._id}`} className="text-green-600">Edit</Link>
            <button onClick={() => onDelete(post._id)} className="text-red-600">Delete</button>
          </div>
        )}
      </div>
    </div>
  );
}