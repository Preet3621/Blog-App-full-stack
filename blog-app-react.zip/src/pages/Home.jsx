import { useState, useEffect } from 'react';
import PostCard from '../components/PostCard';
import { postAPI } from '../services/api';

export default function Home() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const res = await postAPI.getAll();
      setPosts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async (id) => {
    await postAPI.like(id);
    fetchPosts();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this post?')) {
      await postAPI.delete(id);
      fetchPosts();
    }
  };

  if (loading) return <p className="text-center mt-10">Loading...</p>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-4xl font-bold mb-8 text-center">All Blog Posts</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {posts.map(post => (
          <PostCard key={post._id} post={post} onLike={handleLike} onDelete={handleDelete} />
        ))}
      </div>
    </div>
  );
}

