import Post from '../models/Post.js';
import path from 'path';
import fs from 'fs';

class PostController {
  async createPost(req, res) {
    const { title, content } = req.body;
    const author = req.user.id;
    let image = null;

    if (req.file) {
      image = `/uploads/${req.file.filename}`;
    }

    try {
      const post = new Post({ title, content, image, author });
      await post.save();
      res.json(post);
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }

  async getPosts(req, res) {
    try {
      const posts = await Post.find().populate('author', 'username').populate('comments.user', 'username');
      res.json(posts);
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }

  async getPostById(req, res) {
    try {
      const post = await Post.findById(req.params.id).populate('author', 'username').populate('comments.user', 'username');
      if (!post) return res.status(404).json({ msg: 'Post not found' });
      res.json(post);
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }

  async updatePost(req, res) {
    const { title, content } = req.body;
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ msg: 'Post not found' });
      if (post.author.toString() !== req.user.id) return res.status(401).json({ msg: 'Unauthorized' });

      post.title = title || post.title;
      post.content = content || post.content;

      if (req.file) {
        // Delete old image if exists
        if (post.image) {
          fs.unlinkSync(path.join(process.cwd(), post.image));
        }
        post.image = `/uploads/${req.file.filename}`;
      }

      await post.save();
      res.json(post);
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }

  async deletePost(req, res) {
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ msg: 'Post not found' });
      if (post.author.toString() !== req.user.id) return res.status(401).json({ msg: 'Unauthorized' });

      if (post.image) {
        fs.unlinkSync(path.join(process.cwd(), post.image));
      }

      await post.deleteOne();
      return res.json({ msg: 'Post deleted' });
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }

  async likePost(req, res) {
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ msg: 'Post not found' });

      if (post.likes.includes(req.user.id)) {
        post.likes = post.likes.filter(id => id.toString() !== req.user.id);
      } else {
        post.likes.push(req.user.id);
      }

      await post.save();
      res.json({ likes: post.likes.length });
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }

  async commentOnPost(req, res) {
    const { text } = req.body;
    try {
      const post = await Post.findById(req.params.id);
      if (!post) return res.status(404).json({ msg: 'Post not found' });

      post.comments.push({ user: req.user.id, text });
      await post.save();

      const updatedPost = await Post.findById(req.params.id).populate('comments.user', 'username');
      res.json(updatedPost.comments);
    } catch (err) {
      res.status(500).json({ msg: 'Server error' });
    }
  }
}

export default new PostController();